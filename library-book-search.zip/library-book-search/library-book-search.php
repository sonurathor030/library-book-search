<?php
/**
 *
 * @link              https://https://example.com/
 * @since             1.0.0
 * @package           Library_Book_Search
 *
 * @wordpress-plugin
 * 
 * Plugin Name: Library Book Search
 * Plugin URI: https://example.com/
 * Description: A simple library book searching system for WordPress.
 * Version: 1.0.0
 * Author: Sonu Rathor
 * Author URI: https://example.com/
 * Text Domain: library-book-search
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die();
}
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 */
define( 'LIBRARY_BOOK_SEARCH_VERSION', '1.0.0' );

/**
 * define plugin path & url
 */
define( 'PLUGIN_DIR_URL', plugin_dir_url(__FILE__) );
define( 'PLUGIN_DIR_PATH', plugin_dir_path(__FILE__) );

/*** Include book library file */
include_once PLUGIN_DIR_PATH.'includes/lbs-book-library.php';
include_once PLUGIN_DIR_PATH.'public/lbs-searching-book-public.php';

/** Plugin Activation Deactivation Hooks */
register_activation_hook(__FILE__,'lbs_activation_hook');

function lbs_activation_hook(){
    $bookLibrary = new Library_Book_Search();
    $bookLibrary->init();
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__,'lbs_deactivation_hook');
function lbs_deactivation_hook(){
    flush_rewrite_rules();
}


// Initialize the plugin on every page load
add_action( 'init', 'lbs_book_library_run' );
function lbs_book_library_run() {
    $bookLibrary = new Library_Book_Search();
    $bookLibrary->init();
    
    // Initialize the class for shortcode
    new LibraryBookSearch();
}

/** Load language file */
add_action( 'plugins_loaded', 'library_book_search_load_textdomain' );
function library_book_search_load_textdomain() {

    load_plugin_textdomain(
        'library-book-search',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages/'
    );

}

