=== Plugin Name ===
Contributors: sonurathor
Donate link: https://https://example.com//
Tags: books, library
Requires at least: 3.0.1
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple library book searching system for WordPress.

== Description ==

Library Book Search is a versatile WordPress plugin designed to enhance your website with powerful library management and search capabilities. Whether you're running a school library, public library, or a private collection, this plugin allows users to easily browse, search, and filter books directly from your WordPress site.

With an intuitive interface, customizable search options, and seamless integration with your existing WordPress theme, Library Book Search makes it easy to manage a large collection of books. Users can search by title, author, genre, or publication date, making it a perfect solution for libraries of all sizes.

== Features ==

* Advanced Search Functionality: Allow users to search and filter books by title, author, genre, ISBN, and more.
    
* Customizable Search Forms: Easily customize search fields and filters to fit your library's needs.
    
* Responsive Design: The plugin is fully responsive and works seamlessly on all devices, including desktops, tablets, and mobile phones.
    
* Easy Book Management: Add, edit, and manage books from a user-friendly dashboard interface.

* Categories and Tags: Organize books by categories, tags, and custom taxonomies for easier browsing.

* Shortcode Integration: Embed the search form and book listings anywhere on your site using simple shortcodes.

* User-Friendly Interface: Designed with usability in mind, both for administrators and end-users.

== Use Cases ==

* School Libraries: Provide students and teachers with easy access to your book catalog.

* Public Libraries: Allow community members to search and reserve books online.

* Corporate Libraries: Manage your company’s resource library with efficient search tools.

* Personal Collections: Organize and display your private book collection with a professional search interface.

== Installation == 

* Upload the plugin files to the /wp-content/plugins/library-book-search directory, or install the plugin through the WordPress plugins screen directly.

* Activate the plugin through the ‘Plugins’ screen in WordPress.

* Use the 'Library Book Search' menu to configure the plugin settings and start adding books to your collection.

== Frequently Asked Questions == 

Q: Can I customize the search fields?
A: Yes, you can fully customize the search fields to match your library's needs.

Q: Does the plugin support custom post types?
A: Absolutely, the plugin is designed to work with custom post types for maximum flexibility.

Q: Is this plugin compatible with my theme?
A: The plugin is designed to be compatible with most WordPress themes. If you encounter any issues, please contact our support team.

== Changelog ==

= 1.0.0 =

*Initial release with basic search functionality and book management features.