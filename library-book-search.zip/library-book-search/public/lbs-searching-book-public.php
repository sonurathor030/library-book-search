<?php
// Define the class for the library book search functionality
class LibraryBookSearch {
    // Constructor to add the shortcode, enqueue scripts, and add AJAX actions
    public function __construct() {
        /** Add request handler file */
        require_once PLUGIN_DIR_PATH.'public/lbs-request-handler.php';

        add_shortcode('library_book_search', [$this, 'render_search_form']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);

    }

    // Enqueue necessary scripts and styles
    public function enqueue_scripts() {
        wp_enqueue_style('library-book-search-css', PLUGIN_DIR_URL . 'public/assets/css/library-book-search.css');
        wp_enqueue_script('library-book-search-js', PLUGIN_DIR_URL . 'public/assets/js/library-book-search.js', ['jquery'], null, true);
        wp_localize_script('library-book-search-js', 'books_ajax', array( 'ajax_url' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('library_book_search_nonce') ));
    }

    // Render the search form
    public function render_search_form() {
        ob_start();
        ?>
        <form id="library-book-search-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="book-name">Book name:</label>
                    <input type="text" id="book-name" name="book_name">
                </div>
                <div class="form-group">
                    <label for="author">Author:</label>
                    <input type="text" id="author" name="author">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="publisher">Publisher:</label>
                    <select id="publisher" name="publisher">
                        <option value="">Select Publisher</option>
                        <?php echo $this->get_taxonomy_options('publisher'); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="rating">Rating:</label>
                    <select id="rating" name="rating">
                        <option value="">Select Rating</option>
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="price-labels">
                <span>1</span>
                <span>3000</span>
            </div>
            <div class="form-row price-row">
                <label for="price">Price:</label>
                <input type="range" id="price" name="price" min="0" max="3000" value="0" oninput="updatePriceOutput(this)">
            </div>
            <div class="output-container">
                <output class="price-output" >Book Price : 0</output> &#8377;
            </div>
            <div class="form-row">
                <button type="submit" class="search-button">Search</button>
            </div>
            <img src="<?php echo PLUGIN_DIR_URL .'public/assets/img/loader.gif'; ?>" alt="book loader" id="book-loader" class="book-loader" style="display:none;">
        </form>
        <script>
            function updatePriceOutput(rangeInput) {
                const outputElement = document.querySelector('.price-output');
                outputElement.value = 'Book Price: ' + rangeInput.value;
            }
        </script>
        <div id="library-book-search-results">
            <?php echo $this->display_books(); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // Display the all books list
    public function display_books() {
        $args = [
            'post_type' => 'books',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
        ];

        $query = new WP_Query($args);
        ob_start();
        if ($query->have_posts()) {
            ?>
            <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Image</th>
                    <th>Book Name</th>
                    <th>Price</th>
                    <th>Author</th>
                    <th>Publisher</th>
                    <th>Rating</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            while ($query->have_posts()) {
                $query->the_post();
                $book_price = get_post_meta(get_the_ID(), 'book_price', true);
                $book_rating = get_post_meta(get_the_ID(), 'book_star_rating', true);
                $thumbnail = get_the_post_thumbnail(get_the_ID(), 'thumbnail');
                $author_terms = get_the_terms(get_the_ID(), 'book-author');
                $publisher_terms = get_the_terms(get_the_ID(), 'publisher');
                $author_name = $author_terms ? $author_terms[0]->name : '';
                $author_link = $author_terms ? get_term_link($author_terms[0]) : '#';
                $publisher_name = $publisher_terms ? $publisher_terms[0]->name : '';
                $publisher_link = $publisher_terms ? get_term_link($publisher_terms[0]) : '#';
            ?>
                <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo ($thumbnail != '') ? $thumbnail : ''; ?></td>
                <td><a href="<?php echo get_permalink(); ?>"><?php echo esc_html(get_the_title()); ?></a></td>
                <td><?php echo esc_html($book_price); ?></td>
                <td><a href="<?php echo esc_url($author_link); ?>"><?php echo esc_html($author_name); ?></a></td>
                <td><a href="<?php echo esc_url($publisher_link); ?>"><?php echo esc_html($publisher_name); ?></a></td>
                <td><?php echo ($book_rating != '') ? str_repeat('&#9733;', intval($book_rating)) . str_repeat('&#9734;', 5 - intval($book_rating)) : str_repeat('&#9734;', intval(5)); ?></td>
                </tr>
            <?php
            }
            ?>
            </tbody>
            </table>

            <?php
            // Pagination
            $total_pages = $query->max_num_pages;
            if ($total_pages > 1) {
                echo paginate_links([
                    'total' => $total_pages,
                    'current' => max(1, get_query_var('paged')),
                ]);
            }
        } else {
            ?>
            <p>No books found.</p>
            <?php
        }
        wp_reset_postdata();
        return ob_get_clean();
    }

    // Get taxonomy options for select fields
    private function get_taxonomy_options($taxonomy) {
        $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]);
        $options = '';
        foreach ($terms as $term) {
            $options .= sprintf('<option value="%s">%s</option>', $term->slug, $term->name);
        }
        return $options;
    }
}
