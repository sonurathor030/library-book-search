<?php

// Handle AJAX request for book search
function lbs_ajax_search_book() {
    // Verify nonce
    // if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'library_book_search_nonce')) {
    //     wp_send_json_error('Invalid nonce', 403);
    // }

    global $wpdb;

    // Initialize search variables
    $book_name = isset($_GET['book_name']) ? sanitize_text_field($_GET['book_name']) : '';
    $author = isset($_GET['author']) ? sanitize_text_field($_GET['author']) : '';
    $publisher = isset($_GET['publisher']) ? sanitize_text_field($_GET['publisher']) : '';
    $rating = isset($_GET['rating']) ? intval($_GET['rating']) : 0;
    $price = (isset($_GET['price']) && $_GET['price'] > 1) ? intval($_GET['price']) : 0;
    $paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $posts_per_page = 10;
    $offset = ($paged - 1) * $posts_per_page;

    // Base SQL query
    $sql = "SELECT SQL_CALC_FOUND_ROWS p.ID, p.post_title, pm1.meta_value as price, pm2.meta_value as rating 
            FROM {$wpdb->posts} p 
            LEFT JOIN {$wpdb->postmeta} pm1 ON (p.ID = pm1.post_id AND pm1.meta_key = 'book_price') 
            LEFT JOIN {$wpdb->postmeta} pm2 ON (p.ID = pm2.post_id AND pm2.meta_key = 'book_star_rating') 
            WHERE p.post_type = 'books' AND p.post_status = 'publish'";

    // Add conditions based on search parameters
    if ($book_name) {
        $sql .= $wpdb->prepare(" AND p.post_title LIKE %s", $wpdb->esc_like($book_name));
    }
    if ($author) {
        $sql .= $wpdb->prepare(" AND EXISTS (
            SELECT 1 
            FROM {$wpdb->term_relationships} tr 
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
            INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id 
            WHERE tt.taxonomy = 'book-author' AND t.name LIKE %s AND tr.object_id = p.ID
        )", $wpdb->esc_like($author));
    }
    if ($publisher) {
        $sql .= $wpdb->prepare(" AND EXISTS (
            SELECT 1 
            FROM {$wpdb->term_relationships} tr 
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
            INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id 
            WHERE tt.taxonomy = 'publisher' AND t.slug LIKE %s AND tr.object_id = p.ID
        )", $wpdb->esc_like($publisher));
    }
    if ($rating) {
        $sql .= $wpdb->prepare(" AND pm2.meta_value >= %d", $rating);
    }
    if ($price) {
        $sql .= $wpdb->prepare(" AND pm1.meta_value BETWEEN 1 AND %d", $price);
    }

    // Add pagination
    $sql .= $wpdb->prepare(" ORDER BY p.post_date DESC LIMIT %d, %d", $offset, $posts_per_page);
    
    // Execute the query
    $results = $wpdb->get_results($sql);
    $total_rows = $wpdb->get_var("SELECT FOUND_ROWS()");

    // Start building the HTML output
    $output = '';

    if ($results) {
        $output .= '<table>';
        $output .= '<thead><tr><th>No</th><th>Thumbnail</th><th>Book Name</th><th>Price</th><th>Author</th><th>Publisher</th><th>Rating</th></tr></thead>';
        $output .= '<tbody>';
        $i = 1 + $offset;
        
        foreach ($results as $result) {
            $thumbnail = get_the_post_thumbnail($result->ID, 'thumbnail');
            $author_terms = get_the_terms($result->ID, 'book-author');
            $publisher_terms = get_the_terms($result->ID, 'publisher');
            $author_name = $author_terms ? $author_terms[0]->name : '';
            $author_link = $author_terms ? get_term_link($author_terms[0]) : '#';
            $publisher_name = $publisher_terms ? $publisher_terms[0]->name : '';
            $publisher_link = $publisher_terms ? get_term_link($publisher_terms[0]) : '#';
        
            $output .= '<tr>';
            $output .= '<td>' . $i++ . '</td>';
            $output .= '<td>' . $thumbnail . '</td>';
            $output .= '<td><a href="' . get_permalink($result->ID) . '">' . esc_html($result->post_title) . '</a></td>';
            $output .= '<td>' . esc_html($result->price) . '</td>';
            $output .= '<td><a href="' . esc_url($author_link) . '">' . esc_html($author_name) . '</a></td>';
            $output .= '<td><a href="' . esc_url($publisher_link) . '">' . esc_html($publisher_name) . '</a></td>';
            $output .= '<td>' . str_repeat('&#9733;', intval($result->rating)) . str_repeat('&#9734;', 5 - intval($result->rating)) . '</td>';
            $output .= '</tr>';
        }
        $output .= '</tbody>';
        $output .= '</table>';

        // Pagination logic
        if ($total_rows > $posts_per_page) {
            $total_pages = ceil($total_rows / $posts_per_page);
            $output .= '<div class="pagination">';
            for ($page = 1; $page <= $total_pages; $page++) {
                if ($page == $paged) {
                    $output .= '<span>' . $page . '</span>';
                } else {
                    $output .= '<a href="#" data-page="' . $page . '">' . $page . '</a>';
                }
            }
            $output .= '</div>';
        }
    } else {
        $output .= '<p>No books found.</p>';
    }

    wp_send_json_success( $output );
}

add_action('wp_ajax_library_book_search', 'lbs_ajax_search_book');
add_action('wp_ajax_nopriv_library_book_search', 'lbs_ajax_search_book');
