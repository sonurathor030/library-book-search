jQuery(document).ready(function($) {
    $('#library-book-search-form').on('submit', function(event) {
        event.preventDefault();
        
        var data = {
            action: 'library_book_search',
            book_name: $('#book-name').val(),
            author: $('#author').val(),
            publisher: $('#publisher').val(),
            rating: $('#rating').val(),
            price: $('#price').val(),
            security: books_ajax.nonce
        };
        
        $.ajax({
            url: books_ajax.ajax_url,
            type: 'GET',
            data: data,
            beforeSend: function() {
                $('#book-loader').show();
            },
            success: function(response) {
                // Update the results section with the AJAX response
                $('#book-loader').hide();
                $('#library-book-search-results').html(response.data);
            },
            error: function(xhr, status, error) {
                // Handle error
                $('#book-loader').hide();
                console.log('AJAX Error: ' + status + error);
            }
        });
    });
});
