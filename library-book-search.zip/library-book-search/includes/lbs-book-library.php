<?php
if ( !defined( 'ABSPATH' ) ) exit;

class Library_Book_Search {

    // Constructor method
    public function __construct() {
        // Register hooks
        add_action('add_meta_boxes', [$this, 'add_books_meta_box']);
        add_action('save_post', [$this, 'save_books_meta']);
        add_action('admin_menu',[$this, 'wp_add_admin_page_menu']);
    }

    // Method to register post type and taxonomies
    public function init() {
        $this->register_post_type();
        $this->register_taxonomies();
    }

    // Method to register the custom post type
    private function register_post_type() {
        $labels = array(
            'name'               => _x( 'Books', 'post type general name', 'library-book-search' ),
            'singular_name'      => _x( 'Book', 'post type singular name', 'library-book-search' ),
            'menu_name'          => _x( 'Books', 'admin menu', 'library-book-search' ),
            'name_admin_bar'     => _x( 'Book', 'add new on admin bar', 'library-book-search' ),
            'add_new'            => _x( 'Add New', 'book', 'library-book-search' ),
            'add_new_item'       => __( 'Add New Book', 'library-book-search' ),
            'new_item'           => __( 'New Book', 'library-book-search' ),
            'edit_item'          => __( 'Edit Book', 'library-book-search' ),
            'view_item'          => __( 'View Book', 'library-book-search' ),
            'all_items'          => __( 'All Books', 'library-book-search' ),
            'search_items'       => __( 'Search Books', 'library-book-search' ),
            'parent_item_colon'  => __( 'Parent Books:', 'library-book-search' ),
            'not_found'          => __( 'No books found.', 'library-book-search' ),
            'not_found_in_trash' => __( 'No books found in Trash.', 'library-book-search' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'book-library' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array( 'title', 'editor', 'thumbnail' ),
            'menu_icon'          => 'dashicons-book-alt',
        );

        register_post_type( 'books', $args );
    }

    // Method to register custom taxonomies
    private function register_taxonomies() {
        // Register the "Author" taxonomy
        $author_labels = array(
            'name'              => _x( 'Authors', 'taxonomy general name', 'library-book-search' ),
            'singular_name'     => _x( 'Author', 'taxonomy singular name', 'library-book-search' ),
            'search_items'      => __( 'Search Authors', 'library-book-search' ),
            'all_items'         => __( 'All Authors', 'library-book-search' ),
            'parent_item'       => __( 'Parent Author', 'library-book-search' ),
            'parent_item_colon' => __( 'Parent Author:', 'library-book-search' ),
            'edit_item'         => __( 'Edit Author', 'library-book-search' ),
            'update_item'       => __( 'Update Author', 'library-book-search' ),
            'add_new_item'      => __( 'Add New Author', 'library-book-search' ),
            'new_item_name'     => __( 'New Author Name', 'library-book-search' ),
            'menu_name'         => __( 'Author', 'library-book-search' ),
        );

        $author_args = array(
            'hierarchical'      => false,
            'labels'            => $author_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'book-author' ),
        );

        register_taxonomy( 'book-author', array( 'books' ), $author_args );

        // Register the "Publisher" taxonomy
        $publisher_labels = array(
            'name'              => _x( 'Publishers', 'taxonomy general name', 'library-book-search' ),
            'singular_name'     => _x( 'Publisher', 'taxonomy singular name', 'library-book-search' ),
            'search_items'      => __( 'Search Publishers', 'library-book-search' ),
            'all_items'         => __( 'All Publishers', 'library-book-search' ),
            'parent_item'       => __( 'Parent Publisher', 'library-book-search' ),
            'parent_item_colon' => __( 'Parent Publisher:', 'library-book-search' ),
            'edit_item'         => __( 'Edit Publisher', 'library-book-search' ),
            'update_item'       => __( 'Update Publisher', 'library-book-search' ),
            'add_new_item'      => __( 'Add New Publisher', 'library-book-search' ),
            'new_item_name'     => __( 'New Publisher Name', 'library-book-search' ),
            'menu_name'         => __( 'Publisher', 'library-book-search' ),
        );

        $publisher_args = array(
            'hierarchical'      => false,
            'labels'            => $publisher_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'publisher' ),
        );

        register_taxonomy( 'publisher', array( 'books' ), $publisher_args );
    }

    // Method to add meta box
    public function add_books_meta_box() {
        add_meta_box(
            'books_price_meta',
            __('Book Price', 'library-book-search'),
            [$this, 'render_price_books_meta_box'],
            'books',
            'side',
            'core'
        );
        add_meta_box(
            'books_star_rating_meta',
            __('Book Star Rating', 'library-book-search'),
            [$this, 'render_rating_books_meta_box'],
            'books',
            'side',
            'core'
        );
        
    }

    // Method to render meta box fields
    public function render_price_books_meta_box($post) {
        // Nonce field for security
        wp_nonce_field(basename(__FILE__), 'books_nonce');
        
        // Get current values from the database
        $price = get_post_meta($post->ID, 'book_price', true);
        $price = $price ? $price : 1; // Set default price to 1 if empty

        // Output the fields
        ?>
        <p>
            <span style="float:left;">1</span>
            <span style="float:right;">3000</span>
            <input type="range" name="book_price" id="book_price" value="<?php echo esc_attr($price); ?>" min="1" max="3000" step="1" oninput="this.nextElementSibling.value = 'Book Price: ' + this.value" style="width:100%;" />
            <output>Book Price : <?php echo esc_attr($price); ?></output> &#8377;
        </p>
        <?php
    }

    // Method to render meta box fields
    public function render_rating_books_meta_box($post) {
        // Nonce field for security
        wp_nonce_field(basename(__FILE__), 'books_nonce');
        
        // Get current values from the database
        $star_rating = get_post_meta($post->ID, 'book_star_rating', true);

        // Output the fields
        ?>
        <p>
            <select name="book_star_rating" id="book_star_rating" style="width:100%;">
                <option value="" <?php selected($star_rating, ''); ?>>Select book rating</option>
                <option value="1" <?php selected($star_rating, '1'); ?>>1 star</option>
                <option value="2" <?php selected($star_rating, '2'); ?>>2 star</option>
                <option value="3" <?php selected($star_rating, '3'); ?>>3 star</option>
                <option value="4" <?php selected($star_rating, '4'); ?>>4 star</option>
                <option value="5" <?php selected($star_rating, '5'); ?>>5 star</option>
            </select>
        </p>
        <?php
    }
    
    // Method to save meta data
    public function save_books_meta($post_id) {
        // Check if nonce is set
        if (!isset($_POST['books_nonce']) || !wp_verify_nonce($_POST['books_nonce'], basename(__FILE__))) {
            return $post_id;
        }

        // Check for autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        // Check user permissions
        if ('books' === $_POST['post_type']) { // Replace 'books' with your CPT if different
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }
        }

        // Save or update the price
        if (isset($_POST['book_price'])) {
            update_post_meta($post_id, 'book_price', sanitize_text_field($_POST['book_price']));
        }

        // Save or update the star rating
        if (isset($_POST['book_star_rating'])) {
            update_post_meta($post_id, 'book_star_rating', sanitize_text_field($_POST['book_star_rating']));
        }
    }

    // Add submenu page for the shortcode list under the Books CPT menu
    public function wp_add_admin_page_menu() {
        add_submenu_page(
            'edit.php?post_type=books',
            __('Shortcode', 'library-book-search'),
            __('Shortcode', 'library-book-search'),
            'manage_options',
            'shortcode-list',
            [$this, 'render_shortcode_list_page']
        );
    }

    // Callback function to render the shortcode list page
    public function render_shortcode_list_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'library-book-search'));
        }
        include_once PLUGIN_DIR_PATH . 'includes/lbs-shortcode-list.php';
    }
}