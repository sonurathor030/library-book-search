<div class="wrap">
	<h2 style="margin: 0 0 5px;"><?php _e('Shortcodes', 'library-book-search'); ?></h2><hr>
	<h4><?php _e('Available Shortcodes', 'library-book-search'); ?></h4>
	<p class="short-code"><strong><?php _e('1. [library_book_search]', 'library-book-search'); ?></strong> 
	<?php _e('This will show the book search form & search result books table.', 'library-book-search'); ?></p>
</div>
